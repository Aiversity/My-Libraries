This is my raspberry pi servo lib
